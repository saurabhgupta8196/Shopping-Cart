import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { TabledisplayComponent } from './tabledisplay/tabledisplay.component';

@NgModule({
  declarations: [
    AppComponent,
    TabledisplayComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
