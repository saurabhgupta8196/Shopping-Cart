import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
@Component({
  selector: 'app-operation',
  templateUrl: './operation.component.html',
  styleUrls: ['./operation.component.css']
})
export class OperationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  AddEmployee(id, name, sal, dept)
  {
    alert(id+" "+name+" "+sal+" "+dept);
  }

}
