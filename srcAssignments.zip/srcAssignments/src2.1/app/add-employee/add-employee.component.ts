import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {Employee } from '../employee-detail';
import {DataType} from '../DataType';
import { ServeEmployeeService } from '../serve-employee.service';


@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
   

 // emps= Employee;
  emps: DataType[];
  selectedId:number;
  selectedName:string;
  selectedSal:number;
  selectedDept:string;
  title:string;
  
  constructor(private empService: ServeEmployeeService) { }

  getEmployyees(): void 
  {
     this.emps = this.empService.getEmployyees();
  }
  ngOnInit() {
    this.getEmployyees();
  }

  AddEmployee(id,name,sal ,dep)
  {
    this.emps.push(
      {'empId':id,'empName':name,'empSal':sal,'empDep':dep});
      this.title='Data Inserted';
  }


  updateData(id,name,sal,dept):void{
    console.log(id);
    this.selectedId = id;
    this.selectedName=name;
    this.selectedSal=sal;
    this.selectedDept=dept;
  }

  UpdateEmp(a,b,c,d)
  {
      console.log(a);
      for(let i=this.emps.length-1;i>=0;i--)
      {
          if(this.emps[i].empId==this.selectedId)
          {
              if(a!=null)
              {
                  this.emps[i].empId=a;
                  a='';
              } 
              else
              {
                  this.emps[i].empId=this.selectedId;
                  this.selectedId=null;
              }

              if(b!=null)
              {
                  this.emps[i].empName=b;
                  b='';
              } 
              else
              {
                  this.emps[i].empName=this.selectedName;
                  this.selectedName='';
              }

              if(c!=null)
              {
                  this.emps[i].empSal=c;
                  c='';
              } 
              else
              {
                  this.emps[i].empSal=this.selectedSal;
                  this.selectedSal=null;
              }

              if(d!=null)
              {
                  this.emps[i].empDep=d;
                  d='';
              } 
              else
              {
                  this.emps[i].empDep=this.selectedDept;
                  this.selectedDept='';
              }

          }
    
      } 
      this.selectedId=null;
      this.selectedName='';
      this.selectedSal=null;
      this.selectedDept='';
    this.title='Data Updated';
    
  }

  removeEmp(id) 
  {
      var index = this.emps.indexOf(id);
      this.emps.splice(index,1);
       this.title='Data Deleted';
  }
}
