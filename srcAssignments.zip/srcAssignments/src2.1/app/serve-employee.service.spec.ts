import { TestBed, inject } from '@angular/core/testing';

import { ServeEmployeeService } from './serve-employee.service';

describe('ServeEmployeeService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ServeEmployeeService]
    });
  });

  it('should be created', inject([ServeEmployeeService], (service: ServeEmployeeService) => {
    expect(service).toBeTruthy();
  }));
});
