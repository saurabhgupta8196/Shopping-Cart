import { Injectable } from '@angular/core';
import {Employee } from './employee-detail';
import {DataType} from './DataType';


@Injectable({
  providedIn: 'root'
})
export class ServeEmployeeService {

  constructor() { }

  getEmployyees() : DataType[]{

    return Employee;
  }
}
