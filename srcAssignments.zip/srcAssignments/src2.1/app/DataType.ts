export class DataType {
  empId: number;
  empName: string;
  empSal:number;
  empDep:string;
}