import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-sub-comp',
  templateUrl: './sub-comp.component.html',
  styleUrls: ['./sub-comp.component.css']
})
export class SubCompComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
   GoToPage()
  {
    this.router.navigate(['addMovie']);
  }
}
