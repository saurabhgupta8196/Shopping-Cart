import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { AddMoviesComponent } from './add-movies/add-movies.component';
import { AppRoutingModule } from './/app-routing.module';
import { SubCompComponent } from './sub-comp/sub-comp.component';


@NgModule({
  declarations: [
    AppComponent,
    AddMoviesComponent,
    SubCompComponent,
 
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
