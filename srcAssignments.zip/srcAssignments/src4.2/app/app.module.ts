import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule} from '@angular/forms';
import { BookListComponent } from './book-list/book-list.component';
import { BooklistPipe} from './book-list/booklist.pipe';
import { TitleBookListPipe } from './book-list/title-book-list.pipe';
import { YearBookListPipe } from './book-list/year-book-list.pipe';
import { AuthorBookListPipe } from './book-list/author-book-list.pipe';
@NgModule({
  declarations: [
    AppComponent,
    BookListComponent,
    BooklistPipe,
    TitleBookListPipe,
    YearBookListPipe,
    AuthorBookListPipe
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
