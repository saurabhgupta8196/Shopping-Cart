import { TitleBookListPipe } from './title-book-list.pipe';

describe('TitleBookListPipe', () => {
  it('create an instance', () => {
    const pipe = new TitleBookListPipe();
    expect(pipe).toBeTruthy();
  });
});
