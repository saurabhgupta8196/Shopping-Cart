import { BooklistPipe } from './booklist.pipe';

describe('BooklistPipe', () => {
  it('create an instance', () => {
    const pipe = new BooklistPipe();
    expect(pipe).toBeTruthy();
  });
});
