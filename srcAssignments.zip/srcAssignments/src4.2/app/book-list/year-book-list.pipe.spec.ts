import { YearBookListPipe } from './year-book-list.pipe';

describe('YearBookListPipe', () => {
  it('create an instance', () => {
    const pipe = new YearBookListPipe();
    expect(pipe).toBeTruthy();
  });
});
