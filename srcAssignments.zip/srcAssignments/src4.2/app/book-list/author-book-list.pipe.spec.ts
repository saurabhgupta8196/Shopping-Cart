import { AuthorBookListPipe } from './author-book-list.pipe';

describe('AuthorBookListPipe', () => {
  it('create an instance', () => {
    const pipe = new AuthorBookListPipe();
    expect(pipe).toBeTruthy();
  });
});
