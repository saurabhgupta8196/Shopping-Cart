import { Component, OnInit } from '@angular/core';
import {FetchDataServiceService} from '../fetch-data-service.service';
import {Book} from '../book';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit {

  constructor(private bookService: FetchDataServiceService) { }
  books:Book[];
  ngOnInit() {
    this.getBookList();
    console.log(this.books);
  }

   getBookList(): void{
    this.bookService.getBookList().subscribe(books => this.books=books);
  }

}
