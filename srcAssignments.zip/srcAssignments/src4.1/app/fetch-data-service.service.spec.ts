import { TestBed, inject } from '@angular/core/testing';

import { FetchDataServiceService } from './fetch-data-service.service';

describe('FetchDataServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FetchDataServiceService]
    });
  });

  it('should be created', inject([FetchDataServiceService], (service: FetchDataServiceService) => {
    expect(service).toBeTruthy();
  }));
});
