import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-product-form',
  templateUrl: './product-form.component.html',
  styleUrls: ['./product-form.component.css']
})
export class ProductFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  productCategory = ['Grocery', 'Mobile', 'Electronics', 'Cloths'];
  flagBlur: boolean = false;
  stores = [{ name: 'D Mart', checked: false }, { name: 'Big Bazar', checked: false }, { name: 'Mega Store', checked: false }, { name: 'Reliance', checked: false }];


  data = new Product();
  submitted = false;



  validate() {
    this.flagBlur = true;
  }

  validateCheckbox(): boolean {
    for (let s of this.stores) {
      if (s.checked == true) {
        return true;
      }
    }
    return false;
  }



  onsubmit(form: NgForm) {

    this.submitted = true;
    console.log(form.value);
    console.log("Product Id : " + form.value.id);
    console.log("Product Name : " + form.value.name);
    console.log("Product Cost : " + form.value.cost);
    console.log("Product Category : " +form.value.catgeory);
    console.log("Product Online : " + form.value.online);
    for (let store of this.stores) {
      if (store.checked == true) {
        console.log("Available in stores: " + store.name);
      }
    }

  }



  storeClicked(s) {

    for (let i = 0; i < this.stores.length; i++) {

      if (this.stores[i].name == s.name) {
        this.stores[i].checked = !this.stores[i].checked;
        console.log(s);
      }
    }
  }

}



