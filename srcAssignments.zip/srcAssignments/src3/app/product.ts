export class Product {
     productId : number;
     productName : string;
     productCost : number;
     productOnline : boolean;
     productCategory1 : string;
     productAvail : any[];
}
